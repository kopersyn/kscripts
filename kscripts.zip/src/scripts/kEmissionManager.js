// ---------- kEmissionManager Script ----------
// This script manages the processing of emission images for PixInsight
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// ---------------------------------------------

#engine v8

#feature-id kEmissionManager : kScripts Bundle > kEmissionManager
#feature-info Emission Manager script
#feature-icon kEmissionManager.svg
#define TITLE "kEmissionManager"
#define VER "1.4"

#include <pjsr/StdCursor.jsh>
#include <pjsr/TextAlign.jsh>

#include "kScripts/lib/kEmissionManager/Dialog.js"
#include "kScripts/lib/kEmissionManager/Engine.js"
#include "kScripts/lib/STF.js"
#include "kScripts/lib/startup.js"

var EMParameters = {
    targetViewBB: undefined,
    targetViewNB: undefined,
    f_r: 0,
    f_g: 0,
    f_b: 0,
    isLinked: 1,
    previewImage: null,
    tempWindows: []
};

Console.show();

class ScrollControl extends ScrollBox {
  constructor(parent){
    super(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.zoomFactor = 0.2;
    this.minZoomFactor = 0.1;
    this.maxZoomFactor = 10.0;

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            var zoomedWidth = image.width * this.zoomFactor;
            var zoomedHeight = image.height * this.zoomFactor;

            this.setHorizontalScrollRange(0, Math.max(0, zoomedWidth - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, zoomedHeight - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        let p = this.parent;
        p.dragOrigin.x = x;
        p.dragOrigin.y = y;
        p.dragging = true;
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        let p = this.parent;
        if (p.dragging) {
            p.scrollPosition = new Point(p.scrollPosition).translatedBy(p.dragOrigin.x - x, p.dragOrigin.y - y);
            p.dragOrigin.x = x;
            p.dragOrigin.y = y;
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onMouseWheel = function(x, y, delta) {
        const parent = this.parent;
        const oldZoomFactor = parent.zoomFactor;

        if (delta > 0) {
            parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
        } else if (delta < 0) {
            parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
        }

        const zoomRatio = parent.zoomFactor / oldZoomFactor;

        parent.scrollPosition = new Point(
            (parent.scrollPosition.x + x) * zoomRatio - x,
            (parent.scrollPosition.y + y) * zoomRatio - y
        );

        parent.initScrollBars();
        this.update();
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            g.scaleTransformation(this.parent.zoomFactor);
            g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);
            g.drawBitmap(0, 0, result.render());
        }
        g.end();
    };

    this.initScrollBars();
  }
}

function showDialog() {
    let dialog = new emDialog();
    return dialog.execute();
}

function closeTemp() {
    for (let i = 0; i < EMParameters.tempWindows.length; i++) {
        let window = ImageWindow.windowById(EMParameters.tempWindows[i]);
        if (window !== null) {
            window.forceClose();
        }
    }
    EMParameters.tempWindows = [];
}

function main() {
    startup();
    let dialog = new emDialog();
    let retVal = dialog.execute();
    Console.show();

    if (retVal == 1) {
        if (!EMParameters.targetViewBB || !EMParameters.targetViewNB) {
            Console.criticalln("!!! Error: Both Broadband and Narrowband images must be selected. !!!");
            return;
        }

        if(EMParameters.targetViewBB.image.colorSpace == 0 && EMParameters.targetViewNB.image.colorSpace == 1){
            Console.criticalln("!!! Error: Broadband image should be in RGB color space and narrowband should be in grayscale !!!");
            return;
        } else {
            if (EMParameters.targetViewBB.image.colorSpace !== 1) {
                Console.criticalln("!!! Error: Broadband image should be in RGB color space. !!!");
                return;
            }

            if (EMParameters.targetViewNB.image.colorSpace !== 0) {
                Console.criticalln("!!! Error: Narrowband image should be in grayscale. !!!");
                return;
            }
        }
        applyPixelMath();
        closeTemp();
        Console.noteln("Successfully managed emissions.");

        processEvents();
    } else {
        Console.criticalln("Canceled.");
        closeTemp();
    }
}

main();

CoreApplication.ensureMinimumVersion( 1, 9, 4 );
