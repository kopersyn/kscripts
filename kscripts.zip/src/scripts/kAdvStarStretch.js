// ---------- kAdvStarStretch Script ----------
// This script helps with stretching stars.
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// ---------------------------------------------

#feature-id kAdvStarStretch : kScripts Bundle > kAdvStarStretch
#feature-info Advanced Star Stretch script
#feature-icon kAdvStarStretch.svg
#define TITLE "kAdvStarStretch"
#define VERSION "1.7"

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/StdCursor.jsh>

#include "kScripts/lib/kAdvStarStretch/Engine.js"
#include "kScripts/lib/kAdvStarStretch/Dialog.js"

var SParameters = {
  targetView: undefined,
  base: 0.1,
  histogram: 0,
  arcsinh: 1,
  blackPoint: 0,
  rgbw: false,
  clip: false,
  scnr: 0,
  sat: 0,
  previewImage: null,
  tempWindows: []
};

Console.show();
Console.noteln("<br>Successfully loaded kAdvStarStretch V", VERSION, "!<br>");

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.zoomFactor = 0.2;
    this.minZoomFactor = 0.1;
    this.maxZoomFactor = 10.0;

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            var zoomedWidth = image.width * this.zoomFactor;
            var zoomedHeight = image.height * this.zoomFactor;

            this.setHorizontalScrollRange(0, Math.max(0, zoomedWidth - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, zoomedHeight - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        with (this.parent) {
            dragOrigin.x = x;
            dragOrigin.y = y;
            dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        with (this.parent) {
            if (dragging) {
                scrollPosition = new Point(scrollPosition).translatedBy(dragOrigin.x - x, dragOrigin.y - y);
                dragOrigin.x = x;
                dragOrigin.y = y;
            }
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onMouseWheel = function(x, y, delta) {
        const parent = this.parent;
        const oldZoomFactor = parent.zoomFactor;

        if (delta > 0) {
            parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
        } else if (delta < 0) {
            parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
        }

        const zoomRatio = parent.zoomFactor / oldZoomFactor;

        parent.scrollPosition = new Point(
            (parent.scrollPosition.x + x) * zoomRatio - x,
            (parent.scrollPosition.y + y) * zoomRatio - y
        );

        parent.initScrollBars();
        this.update();
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            g.scaleTransformation(this.parent.zoomFactor);
            g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);
            g.drawBitmap(0, 0, result.render());
        }
        g.end();
        gc();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

sDialog();

function showDialog() {
    let dialog = new sDialog();
    return dialog.execute();
}

function main() {
    let dialog = new sDialog();

    // Modify the execute button's onClick handler in the dialog
    dialog.executeButton.onClick = () => {
        if (!SParameters.targetView) {
            Console.criticalln("!!! Error: Stars image must be selected. !!!");
            return;
        }

        try {
            closeTemp();
            Console.noteln("Processing image...");

            if(SParameters.targetView.image.colorSpace == 0){
                Console.warningln("You are working on grayscale image!")
            }

            disableSTF(SParameters.targetView);
            applyStretch(SParameters.targetView,
                        SParameters.arcsinh,
                        SParameters.blackPoint,
                        SParameters.histogram,
                        SParameters.base,
                        SParameters.clip);

            if(SParameters.scnr == 1 && SParameters.targetView.image.colorSpace == 1){
                greenRemoval(SParameters.targetView);
            } else if(SParameters.scnr == 1 && SParameters.targetView.image.colorSpace == 0) {
                Console.warningln("Green Removal can't be used on grayscale images.")
            }

            if(SParameters.sat == 1 && SParameters.targetView.image.colorSpace == 1){
                reduceSaturation(SParameters.targetView);
            } else if(SParameters.sat == 1 && SParameters.targetView.image.colorSpace == 0) {
                Console.warningln("Saturation Reduction can't be used on grayscale images.")
            }

            Console.noteln("Successfully stretched stars.");
            processEvents();

        } catch (error) {
            Console.criticalln("Error during processing: " + error.message);
            closeTemp();
        }
    };

    // Execute the dialog but don't check return value
    dialog.execute();
}


main();
