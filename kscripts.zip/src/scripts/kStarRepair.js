// ---------- kStarRepair Script ----------
// star repair and combine with starless script for PixInsight
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// --------------------------------------

#feature-id kStarRepair : kScripts Bundle > kStarRepair
#feature-info Star repair and combine script
#feature-icon kStarRepair.svg
#define NAME "kStarRepair"
#define VER "1.2"

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>

#include "kScripts/lib/kStarRepair/Engine.js"
#include "kScripts/lib/kStarRepair/Dialog.js"
#include "kScripts/lib/startup.js"

var SRParameters = {
  targetView: undefined,
  targetView2: undefined,
  satAmount: 1,
  replace: false,
  deblow: false,
  cc: false,
  isNarrowband: false,
  blendMode: 1,
  convolutionStrength: 2.0,
  deblowStrength: 1.5,
  saturationLevel: [
    [0.00000, 0.40000],
    [0.50000, 0.70000],
    [1.00000, 0.40000]
  ],

  updateSaturationLevel: function() {
    var satAmount = SRParameters.satAmount;
    SRParameters.saturationLevel = [
      [0.00000, satAmount * 0.40000],
      [0.50000, satAmount * 0.70000],
      [1.00000, satAmount * 0.40000]
    ];
  }
};

krDialog();
krDialog.prototype = new Dialog;

function showDialog() {
    var dialog = new krDialog();
    return dialog.execute();
}

function main() {
    startup();
    let retVal = showDialog();

    if(retVal){
      if (SRParameters.targetView == undefined && SRParameters.targetView2 == undefined) {
        console.criticalln("!!! You haven't chosen any view !!!")
      } else if (SRParameters.targetView == undefined || SRParameters.targetView2 == undefined) {
        console.criticalln("!!! You need to choose second view !!!")
      } else {
          if(SRParameters.targetView.image.colorSpace !== 0 && SRParameters.targetView2.image.colorSpace !== 0){
            console.writeln("Processing RGB images...")
            if(SRParameters.cc == 1){
              if (SRParameters.targetView2.window.hasAstrometricSolution){
                console.writeln("Applying Color Correction...")
                applyPhotometricColorCalibration(SRParameters.targetView2);
              } else {
                console.criticalln("Cannot process: Image has no astrometric solution, skipping");
              }
              if(SRParameters.deblow == 1){
                applyStarProcessing(SRParameters.targetView2);
              }
              applyColorSaturation(SRParameters.targetView2);
              applyStarRepair(SRParameters.targetView2);
              combineViews(SRParameters.targetView, SRParameters.targetView2);
              console.noteln("Successfully repaired stars!")
            } else {
              if(SRParameters.cc == 1){
                console.warningln("Cannot process: Color Calibration can't run on grayscale image, skipping...")
              }
              if(SRParameters.deblow == 1){
                applyStarProcessing(SRParameters.targetView2);
              }
              applyColorSaturation(SRParameters.targetView2);
              applyStarRepair(SRParameters.targetView2);
              combineViews(SRParameters.targetView, SRParameters.targetView2);
              console.noteln("Successfully repaired stars!")
            }
          } else if(SRParameters.targetView.image.colorSpace !== 1 && SRParameters.targetView2.image.colorSpace !== 1){
            console.writeln("Processing grayscale images...");
            if(SRParameters.deblow == 1){
              applyStarProcessing(SRParameters.targetView2);
            }
            combineViews(SRParameters.targetView, SRParameters.targetView2);
            console.noteln("Successfully repaired stars!")
          } else {
            console.criticalln("Cannot process: Image is in undefined colorspace.")
          }
        }
    } else {
      console.criticalln("Canceled repairing.")
    }
}

main();
