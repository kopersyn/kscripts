// ---------- kHaBlending Script ----------
// This script blends Ha with RGB image.
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// ---------------------------------------------

#feature-id kHaBlending : kScripts Bundle > kHaBlending
#feature-info Emission Manager script
#feature-icon kHaBlending.svg
#define TITLE "kHaBlending"
#define VER "1.5"

#engine v8

#include <pjsr/StdCursor.jsh>
#include <pjsr/TextAlign.jsh>

#include "kScripts/lib/kHaBlending/Engine.js"
#include "kScripts/lib/kHaBlending/Dialog.js"
#include "kScripts/lib/STF.js"
#include "kScripts/lib/startup.js"

var HaParameters = {
    targetViewBB: undefined,
    targetViewNB: undefined,
    ha: 0.5,
    isLinked: 1,
    previewImage: null,
    tempWindows: []
};

Console.show();

class ScrollControl extends ScrollBox {
  constructor(parent){
    super(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);
    this.zoomFactor = 0.2;
    this.minZoomFactor = 0.1;
    this.maxZoomFactor = 10.0;

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            var zoomedWidth = image.width * this.zoomFactor;
            var zoomedHeight = image.height * this.zoomFactor;

            this.setHorizontalScrollRange(0, Math.max(0, zoomedWidth - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, zoomedHeight - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        let p = this.parent;
        p.dragOrigin.x = x;
        p.dragOrigin.y = y;
        p.dragging = true;
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        let p = this.parent;
        if (p.dragging) {
            p.scrollPosition = new Point(p.scrollPosition).translatedBy(p.dragOrigin.x - x, p.dragOrigin.y - y);
            p.dragOrigin.x = x;
            p.dragOrigin.y = y;
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onMouseWheel = function(x, y, delta) {
        const parent = this.parent;
        const oldZoomFactor = parent.zoomFactor;

        if (delta > 0) {
            parent.zoomFactor = Math.min(parent.zoomFactor * 1.25, parent.maxZoomFactor);
        } else if (delta < 0) {
            parent.zoomFactor = Math.max(parent.zoomFactor * 0.8, parent.minZoomFactor);
        }

        const zoomRatio = parent.zoomFactor / oldZoomFactor;

        parent.scrollPosition = new Point(
            (parent.scrollPosition.x + x) * zoomRatio - x,
            (parent.scrollPosition.y + y) * zoomRatio - y
        );

        parent.initScrollBars();
        this.update();
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            g.scaleTransformation(this.parent.zoomFactor);
            g.translateTransformation(-this.parent.scrollPosition.x, -this.parent.scrollPosition.y);
            g.drawBitmap(0, 0, result.render());
        }
        g.end();
    };

    this.initScrollBars();
  }
}

function showDialog() {
    let dialog = new hDialog();
    return dialog.execute();
}

function closeTemp() {
    for (let i = 0; i < HaParameters.tempWindows.length; i++) {
        let window = ImageWindow.windowById(HaParameters.tempWindows[i]);
        if (window !== null) {
            window.forceClose();
        }
    }
    HaParameters.tempWindows = [];
}

function main() {
    startup();
    let dialog = new hDialog();
    let retVal = dialog.execute();
    Console.show();

    if (retVal == 1) {
        if (!HaParameters.targetViewBB || !HaParameters.targetViewNB) {
            Console.criticalln("!!! Error: Both Broadband and Narrowband images must be selected. !!!");
            return;
        }

        if(HaParameters.targetViewBB.image.colorSpace == 0 && HaParameters.targetViewNB.image.colorSpace == 1){
            Console.criticalln("!!! Error: Broadband image should be in RGB color space and narrowband should be in grayscale !!!");
            return;
        } else {
            if (HaParameters.targetViewBB.image.colorSpace !== 1) {
                Console.criticalln("!!! Error: Broadband image should be in RGB color space. !!!");
                return;
            }

            if (HaParameters.targetViewNB.image.colorSpace !== 0) {
                Console.criticalln("!!! Error: Narrowband image should be in grayscale. !!!");
                return;
            }
        }
        applyPixelMath();
        closeTemp();
        Console.noteln("Successfully blended.");

        processEvents();
    } else {
        Console.criticalln("Canceled.");
        closeTemp();
    }
}

main();

CoreApplication.ensureMinimumVersion( 1, 9, 4 );
