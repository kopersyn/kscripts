// ---------- kHaBlending Script ----------
// This script blends Ha with RGB image.
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// ---------------------------------------------

// WORKS BEST WITH 1.9 AND HIGHER VERSIONS OF PIXINSIGHT

#feature-id kScripts Bundle > kHaBlending
#feature-info Emission Manager script
#define TITLE "kHaBlending"
#define VERSION "1.0"

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/StdCursor.jsh>

var EMParameters = {
    targetViewBB: undefined,
    targetViewNB: undefined,
    ha: 0.5,
    previewImage: null,
    tempWindows: []
};

Console.show();
Console.noteln("Successfully loaded kHaBlending v", VERSION, "!<br>");

function ScrollControl(parent) {
    this.__base__ = ScrollBox;
    this.__base__(parent);

    this.autoScroll = true;
    this.tracking = true;

    this.displayImage = null;
    this.dragging = false;
    this.dragOrigin = new Point(0);

    this.viewport.cursor = new Cursor(StdCursor_OpenHand);

    this.getImage = function() {
        return this.displayImage;
    };

    this.doUpdateImage = function(image) {
        this.displayImage = image;
        this.initScrollBars();
        this.viewport.update();
    };

    this.initScrollBars = function() {
        var image = this.getImage();
        if (image == null || image.width <= 0 || image.height <= 0) {
            this.setHorizontalScrollRange(0, 0);
            this.setVerticalScrollRange(0, 0);
        } else {
            this.setHorizontalScrollRange(0, Math.max(0, image.width - this.viewport.width));
            this.setVerticalScrollRange(0, Math.max(0, image.height - this.viewport.height));
        }
        this.viewport.update();
    };

    this.viewport.onResize = function() {
        this.parent.initScrollBars();
    };

    this.onHorizontalScrollPosUpdated = function(x) {
        this.viewport.update();
    };

    this.onVerticalScrollPosUpdated = function(y) {
        this.viewport.update();
    };

    this.viewport.onMousePress = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_ClosedHand);
        with (this.parent) {
            dragOrigin.x = x;
            dragOrigin.y = y;
            dragging = true;
        }
    };

    this.viewport.onMouseMove = function(x, y, buttons, modifiers) {
        with (this.parent) {
            if (dragging) {
                scrollPosition = new Point(scrollPosition).translatedBy(dragOrigin.x - x, dragOrigin.y - y);
                dragOrigin.x = x;
                dragOrigin.y = y;
            }
        }
    };

    this.viewport.onMouseRelease = function(x, y, button, buttons, modifiers) {
        this.cursor = new Cursor(StdCursor_OpenHand);
        this.parent.dragging = false;
    };

    this.viewport.onPaint = function(x0, y0, x1, y1) {
        var g = new Graphics(this);
        var result = this.parent.getImage();
        if (result == null) {
            g.fillRect(x0, y0, x1, y1, new Brush(0xff000000));
        } else {
            result.selectedRect = (new Rect(x0, y0, x1, y1)).translated(this.parent.scrollPosition);
            g.drawBitmap(x0, y0, result.render());
            result.resetRectSelection();
        }
        g.end();
        gc();
    };

    this.initScrollBars();
}
ScrollControl.prototype = new ScrollBox;

function hDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = "kScripts - kHaBlending";
    this.scaledMinWidth = 600;
    this.scaledMinHeight = 600;
    this.setFixedSize(1200, 600);



    this.titleBox = new Label(this);
    this.titleBox.text = "kHaBlending " + VERSION;
    this.titleBox.textAlignment = TextAlign_Center;
    this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f7e1e1; border: 1px solid #ccc;";
    this.titleBox.setFixedHeight(30);
    this.titleBox.setFixedWidth(300);

    this.instructionsBox = new Label(this);
    this.instructionsBox.text = "Use non-linear state images for best results.\nBroadband image should be RGB, but Ha should \nbe in grayscale.\nChange Ha value to add Ha signal to image";
    this.instructionsBox.textAlignment = TextAlign_Center;
    this.instructionsBox.styleSheet = "font-size: 8pt; padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc;";
    this.instructionsBox.setFixedHeight(75);
    this.instructionsBox.setFixedWidth(300);  // Reduced from default

    this.viewListLabelBB = new Label(this);
    this.viewListLabelBB.text = "Broadband Image:";

    this.viewListLabelNB = new Label(this);
    this.viewListLabelNB.text = "Ha Image:";

    this.viewListBB = new ViewList(this);
    this.viewListBB.setFixedWidth(300);  // Reduced from default
    this.viewListBB.getMainViews();
    this.viewListBB.onViewSelected = function(view) {
        EMParameters.targetViewBB = view;
        Console.write("Broadband Image Selected: " + view.id);
    };

    this.viewListNB = new ViewList(this);
    this.viewListNB.setFixedWidth(300);
    this.viewListNB.getMainViews();
    this.viewListNB.onViewSelected = function(view) {
        EMParameters.targetViewNB = view;
        Console.write("Ha Image Selected: " + view.id);
    };

    this.ha_control = new NumericControl(this);
    this.ha_control.label.text = "Ha quantity:";
    this.ha_control.setFixedWidth(300);
    this.ha_control.setRange(0, 1);
    this.ha_control.setValue(0.1);
    this.ha_control.setPrecision(2);
    this.ha_control.slider.setRange(1, 500);
    this.ha_control.setValue(EMParameters.ha);
    this.ha_control.onValueUpdated = function(value) {
        EMParameters.ha = value;
    };

    this.authorshipLabel = new Label(this);
    this.authorshipLabel.text = "Written by Igor Koprowicz\n© Copyright 2024-2025";
    this.authorshipLabel.textAlignment = TextAlign_Center;

    this.executeButton = new PushButton(this);
    this.executeButton.text = "Execute";
    this.executeButton.onClick = () => {
        this.ok();
    }
    this.executeButton.setFixedHeight(30);

    this.stf = function(view) {
      let P = new PixelMath;
      P.expression = "Stretch=  0.20 ; \n" +
      "Curve=    1.00 ; \n" +
      "Clip=      2 ; \n" +
      "\n" +
      "\n" +
      "E1= min(max(0,med($T)+-Clip*1.4826*mdev($T)),1);\n" +
      "E2= max(0,($T-E1)/~E1); \n" +
      "E3= med($T)-E1;\n" +
      "E4= min(1,(1/Curve));\n" +
      "E5= ((Stretch-1)*E3) / ((2*Stretch-1) * E3^E4-Stretch); \n" +
      "E6= ( (E5-1)*E2) / ( (2*E5-1) * E2^E4-E5);\n" +
      "\n" +
      "E6";
      P.useSingleExpression = true;
      P.symbols = "Stretch,Curve,Clip,\n" +
      "E1,E2,E3,E4,E5,E6,E7,";
      P.clearImageCacheAndExit = false;
      P.cacheGeneratedImages = false;
      P.generateOutput = true;
      P.singleThreaded = false;
      P.optimization = true;
      P.use64BitWorkingImage = true;
      P.rescale = false;
      P.rescaleLower = 0;
      P.rescaleUpper = 1;
      P.truncate = true;
      P.truncateLower = 0;
      P.truncateUpper = 1;
      P.createNewImage = false;
      P.showNewImage = true;
      P.executeOn(view);
  };


    this.mainSizer = new HorizontalSizer();
    this.mainSizer.margin = 10;

    this.previewControl = new ScrollControl(this);
    this.previewControl.setFixedSize(750, 550);
    this.previewControl.scrollBarsVisible = false;

    this.updatePreview = function() {
            if (EMParameters.targetViewBB && EMParameters.targetViewBB.image && EMParameters.targetViewNB && EMParameters.targetViewNB.image) {
                if (EMParameters.targetViewBB.image.colorSpace == 1 && EMParameters.targetViewNB.image.colorSpace == 0) {
                    Console.noteln("Updating preview...");

                    try {
                        let tempImage = new Image(EMParameters.targetViewBB.image.width, EMParameters.targetViewBB.image.height,
                                                  EMParameters.targetViewBB.image.numberOfChannels);

                        tempImage.assign(EMParameters.targetViewBB.image);

                        let window = new ImageWindow(tempImage.width, tempImage.height, tempImage.numberOfChannels,
                                                     tempImage.bitsPerSample, tempImage.isReal, tempImage.isColor);

                        EMParameters.tempWindows.push(window.mainView.id);

                        let tempView = window.mainView;

                        let P = new PixelMath();

                        P.expression = EMParameters.targetViewNB.fullId + " * " + EMParameters.ha + " + " + EMParameters.targetViewBB.fullId + " * " + EMParameters.ha;
                        P.expression1 = EMParameters.targetViewBB.fullId;
                        P.expression2 = EMParameters.targetViewBB.fullId;

                        P.useSingleExpression = false;
                        P.createNewImage = false;
                        P.executeOn(tempView);

                        if (this.autoSTFCheckbox.checked) {
                            this.stf(tempView);
                        }

                        let P_resample = new IntegerResample();
                        const previewWidth = this.previewControl.width;
                        const widthScale = Math.floor(tempImage.width / previewWidth);
                        P_resample.zoomFactor = -Math.max(widthScale, 0.5);
                        P_resample.executeOn(tempView);

                        this.previewControl.displayImage = tempView.image;
                        this.previewControl.doUpdateImage(tempView.image);
                        this.previewControl.initScrollBars();

                        Console.noteln("Preview updated successfully.");

                    } catch (error) {
                        Console.criticalln("Error in preview update: " + error.message);
                    }
                } else {
                    Console.criticalln("Error: Broadband image should be in RGB color space and narrowband should be in grayscale.");
                }
            }
        };

    this.refreshPreviewButton = new PushButton(this);
    this.refreshPreviewButton.text = "Refresh Preview";
    this.refreshPreviewButton.onClick = () => {
        if (EMParameters.targetViewBB && EMParameters.targetViewNB) {
            this.updatePreview();
        } else {
            Console.criticalln("Select both Broadband and Narrowband images before refreshing preview.");
        }
    };
    this.refreshPreviewButton.setFixedHeight(30);

    this.autoSTFCheckbox = new CheckBox(this);
    this.autoSTFCheckbox.text = "Auto STF";
    this.autoSTFCheckbox.checked = false;
    this.autoSTFCheckbox.onClick = function() {
      if (EMParameters.targetViewBB && EMParameters.targetViewNB) {
          this.dialog.updatePreview();
      } else {
          Console.criticalln("Select both Broadband and Narrowband images before applying Auto STF.");
      }
    };

    this.createPreviewImage = function() {
        let P = new PixelMath;
        P.expression = EMParameters.targetViewNB.fullId + " * " + EMParameters.ha + " + " + EMParameters.targetViewBB.fullId + " * " + EMParameters.ha;
        P.expression1 = EMParameters.targetViewBB.fullId;
        P.expression2 = EMParameters.targetViewBB.fullId;
        P.useSingleExpression = false;
        P.createNewImage = true;
        P.newImageId = "Preview";
        P.newImageWidth = 0;
        P.newImageHeight = 0;
        P.newImageAlpha = false;
        P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
        P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

        P.executeGlobal();
        return View.viewById("Preview").image;
    };


    this.viewListBB.onViewSelected = function(view) {
        EMParameters.targetViewBB = view;
        this.dialog.updatePreview();
    }.bind(this);

    this.viewListNB.onViewSelected = function(view) {
        EMParameters.targetViewNB = view;
        this.dialog.updatePreview();
    }.bind(this);

    let buttonSizer = new HorizontalSizer();
    buttonSizer.add(this.refreshPreviewButton);
    buttonSizer.addSpacing(10);
    buttonSizer.add(this.executeButton);

    // Left sizer for controls
    let leftSizer = new VerticalSizer();
    leftSizer.spacing = 4;
    leftSizer.margin = 8;
    leftSizer.addStretch();
    leftSizer.add(this.titleBox);
    leftSizer.addSpacing(5);
    leftSizer.add(this.instructionsBox);
    leftSizer.addSpacing(10);
    leftSizer.add(this.viewListLabelBB);
    leftSizer.addSpacing(3);
    leftSizer.add(this.viewListBB);
    leftSizer.addSpacing(10);
    leftSizer.add(this.viewListLabelNB);
    leftSizer.addSpacing(3);
    leftSizer.add(this.viewListNB);
    leftSizer.addSpacing(10);
    leftSizer.add(this.ha_control);
    leftSizer.addSpacing(3);
    leftSizer.addSpacing(15);
    leftSizer.add(buttonSizer);
    leftSizer.addSpacing(10);
    leftSizer.add(this.authorshipLabel);
    leftSizer.addStretch();

    let previewSizer = new VerticalSizer();
    previewSizer.margin = 8;
    previewSizer.spacing = 4;
    previewSizer.addStretch();
    previewSizer.addSpacing(2);
    previewSizer.add(this.autoSTFCheckbox);
    previewSizer.addSpacing(2);
    previewSizer.add(this.previewControl);
    previewSizer.addSpacing(8);
    previewSizer.addStretch();

    this.mainSizer = new HorizontalSizer();
    this.mainSizer.margin = 8;
    this.mainSizer.spacing = 8;
    this.mainSizer.add(leftSizer);
    this.mainSizer.addSpacing(8);
    this.mainSizer.add(previewSizer);

    this.sizer = this.mainSizer;
}

hDialog.prototype = new Dialog;

function showDialog() {
    let dialog = new hDialog();
    return dialog.execute();
}

function applyPixelMath() {
    let P = new PixelMath;

    P.expression = EMParameters.targetViewNB.fullId + " * " + EMParameters.ha + " + " + EMParameters.targetViewBB.fullId + " * " + EMParameters.ha;
    P.expression1 = EMParameters.targetViewBB.fullId;
    P.expression2 = EMParameters.targetViewBB.fullId;

    P.useSingleExpression = false;
    P.createNewImage = true;
    P.newImageId = "Combined";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    P.executeOn(EMParameters.targetViewBB);
}

function closeTemp() {
    for (let i = 0; i < EMParameters.tempWindows.length; i++) {
        let window = ImageWindow.windowById(EMParameters.tempWindows[i]);
        if (window !== null) {
            window.forceClose();
        }
    }
    EMParameters.tempWindows = [];
}

function main() {
    let dialog = new hDialog();
    let retVal = dialog.execute();
    Console.show();

    if (retVal == 1) {
        if (!EMParameters.targetViewBB || !EMParameters.targetViewNB) {
            Console.criticalln("!!! Error: Both Broadband and Narrowband images must be selected. !!!");
            return;
        }

        if(EMParameters.targetViewBB.image.colorSpace == 0 && EMParameters.targetViewNB.image.colorSpace == 1){
            Console.criticalln("!!! Error: Broadband image should be in RGB color space and narrowband should be in grayscale !!!");
            return;
        } else {
            if (EMParameters.targetViewBB.image.colorSpace !== 1) {
                Console.criticalln("!!! Error: Broadband image should be in RGB color space. !!!");
                return;
            }

            if (EMParameters.targetViewNB.image.colorSpace !== 0) {
                Console.criticalln("!!! Error: Narrowband image should be in grayscale. !!!");
                return;
            }
        }
        applyPixelMath();
        closeTemp();
        Console.note("Successfully managed emissions.");

        processEvents();
    } else {
        Console.criticalln("Canceled.");
        closeTemp();
    }
}

main();
