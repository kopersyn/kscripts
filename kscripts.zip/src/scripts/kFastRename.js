#feature-id kStarRepair : kScripts Bundle > kFastRename
#feature-info Fast rename using ImageIdentifier process
#feature-icon kFastRename.svg
#define NAME "kFastRename"
#define VER "1.0"

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>

#include "kScripts/lib/startup.js"

var FRParameters = {
  lChannel: undefined,
  rChannel: undefined,
  gChannel: undefined,
  bChannel: undefined,
  sChannel: undefined,
  hChannel: undefined,
  oChannel: undefined
}

function getScaledResource(resourcePath) {
   return resourcePath;
}

function FRDialog(){
  this.__base__ = Dialog;
  this.__base__();

  this.windowTitle = "kScripts - kFastRename";
  this.scaledMinWidth = 300;
  this.scaledMinHeight = 600;

  this.titleSizer = new VerticalSizer;
  this.titleSizer.spacing = 15;

  this.titleBox = new Label(this);
  this.titleBox.text = "kFastRename " + VER;
  this.titleBox.textAlignment = TextAlign_Center;
  this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #d7e7fa; border: 1px solid #ccc;";
  this.titleBox.setFixedHeight(40);

  this.instructionsBox = new Label(this);
  this.instructionsBox.text = "Script that fasten renaming image previews.";
  this.instructionsBox.textAlignment = TextAlign_Center;
  this.instructionsBox.styleSheet = "font-size: 8pt; padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc;";
  this.instructionsBox.setFixedHeight(40);

  this.LVL = new Label(this);
  this.LVL.text = "Luminance channel"

  this.RVL = new Label(this);
  this.RVL.text = "Red channel"

  this.GVL = new Label(this);
  this.GVL.text = "Green channel"

  this.BVL = new Label(this);
  this.BVL.text = "Blue channel"

  this.SVL = new Label(this);
  this.SVL.text = "Sulfur channel"

  this.HVL = new Label(this);
  this.HVL.text = "Hydrogen-alpha channel"

  this.OVL = new Label(this);
  this.OVL.text = "Oxygen channel"

  this.LList = new ViewList(this);
  this.LList.getMainViews();
  this.LList.onViewSelected = function(view) {
      FRParameters.lChannel = view;
  };

  this.RList = new ViewList(this);
  this.RList.getMainViews();
  this.RList.onViewSelected = function(view) {
      FRParameters.rChannel = view;
  };

  this.GList = new ViewList(this);
  this.GList.getMainViews();
  this.GList.onViewSelected = function(view) {
      FRParameters.gChannel = view;
  };

  this.BList = new ViewList(this);
  this.BList.getMainViews();
  this.BList.onViewSelected = function(view) {
      FRParameters.bChannel = view;
  };

  this.SList = new ViewList(this);
  this.SList.getMainViews();
  this.SList.onViewSelected = function(view) {
      FRParameters.sChannel = view;
  };

  this.HList = new ViewList(this);
  this.HList.getMainViews();
  this.HList.onViewSelected = function(view) {
      FRParameters.hChannel = view;
  };

  this.OList = new ViewList(this);
  this.OList.getMainViews();
  this.OList.onViewSelected = function(view) {
      FRParameters.oChannel = view;
  };

  this.titleSizer.add(this.titleBox);;
  this.titleSizer.add(this.instructionsBox);
  this.titleSizer.addSpacing(5);

  this.leftSizer = new VerticalSizer;
  this.leftSizer.add(this.LVL);
  this.leftSizer.addSpacing(5);
  this.leftSizer.add(this.LList);
  this.leftSizer.addSpacing(15);
  this.leftSizer.add(this.RVL);
  this.leftSizer.addSpacing(5);
  this.leftSizer.add(this.RList);
  this.leftSizer.addSpacing(15);
  this.leftSizer.add(this.GVL);
  this.leftSizer.addSpacing(5);
  this.leftSizer.add(this.GList);
  this.leftSizer.addSpacing(15);
  this.leftSizer.add(this.BVL);
  this.leftSizer.addSpacing(5);
  this.leftSizer.add(this.BList);
  this.leftSizer.addSpacing(15);
  this.leftSizer.add(this.SVL);
  this.leftSizer.addSpacing(5);
  this.leftSizer.add(this.SList);
  this.leftSizer.addSpacing(15);
  this.leftSizer.add(this.HVL);
  this.leftSizer.addSpacing(5);
  this.leftSizer.add(this.HList);
  this.leftSizer.addSpacing(15);
  this.leftSizer.add(this.OVL);
  this.leftSizer.addSpacing(5);
  this.leftSizer.add(this.OList);
  this.leftSizer.addSpacing(5);

  this.authorshipLabel = new Label(this);
  this.authorshipLabel.text = "Written by Igor Koprowicz\n© Copyright 2025";
  this.authorshipLabel.textAlignment = TextAlign_Center;

  this.executeButton = new PushButton(this);
  this.executeButton.icon = getScaledResource(":/floating-window/commit.png");
  this.executeButton.setScaledFixedSize(100, 30); // większy rozmiar, bo PushButton jest większy niż ToolButton
  this.executeButton.text = "Execute";
  this.executeButton.toolTip = "Execute script";
  this.executeButton.onClick = () => {
      this.ok();
  };

  this.centerSizer = new HorizontalSizer;
  this.centerSizer.add(this.executeButton);

  this.verSizer = new VerticalSizer;
  this.verSizer.insertStretch(0);
  this.verSizer.addSpacing(30);
  this.verSizer.add(this.titleSizer);
  this.verSizer.addSpacing(10);
  this.verSizer.add(this.leftSizer);
  this.verSizer.addSpacing(20);
  this.verSizer.add(this.authorshipLabel);
  this.verSizer.addSpacing(20);
  this.verSizer.add(this.centerSizer);
  this.verSizer.addStretch();

  this.mainSizer = new HorizontalSizer;
  this.mainSizer.addStretch();
  this.mainSizer.add(this.verSizer);
  this.mainSizer.addStretch();

  this.sizer = this.mainSizer;
}

FRDialog();
FRDialog.prototype = new Dialog;

function showDialog() {
    var dialog = new FRDialog();
    return dialog.execute();
}

function main() {
  startup();
  let retVal = showDialog();

  if (!retVal)
    return;

  function renameView(view, newId) {
    if (!view || !view.isView)
      return;

    let originalName = view.fullId;

    let identifier = new ImageIdentifier;
    identifier.id = newId;

    try {
      identifier.executeOn(view);
      console.writeln("Renamed: " + originalName + " → " + newId);
    } catch (e) {
      console.criticalln("Failed to rename " + originalName + ": " + e);
    }
  }

  renameView(FRParameters.lChannel, "L");
  renameView(FRParameters.rChannel, "R");
  renameView(FRParameters.gChannel, "G");
  renameView(FRParameters.bChannel, "B");
  renameView(FRParameters.sChannel, "SII");
  renameView(FRParameters.hChannel, "Ha");
  renameView(FRParameters.oChannel, "OIII");
  Console.noteln("Successfully renamed.")
}

main();
