// ---------- kDenoiser Script ----------
// tryna be best denoiser for PixInsight
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check my other scripts at https://www.kscripts.pl/
// --------------------------------------

#feature-id kScripts Bundle > kDenoiser
#feature-info Image denoiser script
#define TITLE "kDenoiser"
#define VERSION "0.4"

#include <pjsr/NumericControl.jsh>
#include <pjsr/Sizer.jsh>

var DenoiseParameters = {
  targetView: undefined,
};

function colorDenoise(view) {
  var PCE = new ChannelExtraction;
  PCE.colorSpace = ChannelExtraction.prototype.RGB;
  PCE.channels = [ // enabled, id
     [true, "R"],
     [true, "G"],
     [true, "B"]
  ];
  PCE.sampleFormat = ChannelExtraction.prototype.SameAsSource;
  PCE.inheritAstrometricSolution = true;
  PCE.executeOn(view);

  var PLRGB = new LRGBCombination;
  PLRGB.channels = [ // enabled, id, k
     [true, "R", 1.00000],
     [true, "G", 1.00000],
     [true, "B", 1.00000],
     [false, "", 1.00000]
  ];
  PLRGB.mL = 0.500;
  PLRGB.mc = 0.500;
  PLRGB.clipHighlights = true;
  PLRGB.noiseReduction = true;
  PLRGB.layersRemoved = 4;
  PLRGB.layersProtected = 2;
  PLRGB.inheritAstrometricSolution = true;
  PLRGB.executeOn(view);

  var Rview = View.viewById("R");
  var Gview = View.viewById("G");
  var Bview = View.viewById("B");

  if (Rview != null) Rview.window.close();
  if (Gview != null) Gview.window.close();
  if (Bview != null) Bview.window.close();
}

Console.noteln("Successfully loaded kDenoiser v", VERSION, "!<br>");

function kdDialog() {
    this.__base__ = Dialog;
    this.__base__();
    this.windowTitle = "kScripts - kDenoiser";

    // scaling
    this.scaledMinWidth = 400;

    // Title sizer
    this.titleSizer = new VerticalSizer;
    this.titleSizer.spacing = 4;

    // Title label
    this.titleBox = new Label(this);
    this.titleBox.text = "kDenoiser " + VERSION;
    this.titleBox.textAlignment = TextAlign_Center;
    this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #f0f0f0; border: 1px solid #ccc;"; // Custom styles with border
    this.titleBox.setFixedHeight(30); // Fixed height for the title

    this.instructionsBox = new Label(this);
    this.instructionsBox.text = "This script removes color noise from your image.";
    this.instructionsBox.textAlignment = TextAlign_Center;
    this.instructionsBox.styleSheet = "font-size: 8pt; padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc;"; // Custom styles
    this.instructionsBox.setFixedHeight(40); // Adjust height as needed

    // Add titleBox to the titleSizer
    this.titleSizer.add(this.titleBox);
    this.titleSizer.addSpacing(5);
    this.titleSizer.add(this.instructionsBox);
    this.titleSizer.addSpacing(20);

    // View list
    this.viewList = new ViewList(this);
    this.viewList.getMainViews();
    this.viewList.onViewSelected = function(view) {
        DenoiseParameters.targetView = view;
    };

    // Execute button
    this.executeButton = new PushButton(this);
    this.executeButton.text = "Execute";
    this.executeButton.onClick = () => {
        this.ok();
    };

    // Bottom sizer
    this.bottomSizer = new HorizontalSizer;
    this.bottomSizer.margin = 6;
    this.bottomSizer.addStretch(); // Add stretchable space before the button
    this.bottomSizer.add(this.executeButton, 100); // Allow the button to expand
    this.bottomSizer.addStretch(); // Add stretchable space after the button

    // Main sizer
    this.sizer = new VerticalSizer();
    this.sizer.add(this.titleSizer); // Add the title sizer
    this.sizer.addSpacing(8);
    this.sizer.add(this.viewList);
    this.sizer.addSpacing(15);
    this.sizer.add(this.bottomSizer);
    this.sizer.margin = 20;
    this.sizer.addStretch();
}

kdDialog.prototype = new Dialog;

function showDialog() {
  let dialog = new kdDialog;
  return dialog.execute();
}

function main() {
  if (Parameters.isGlobalTarget) {
    let warnMessage = "Script cannot execute in global context";
    (new MessageBox(warnMessage, "Warning", StdIcon_Warning, StdButton_Ok)).execute();
    return;
  }

  let retVal = showDialog();
  Console.show();

  if (retVal == 1) {
    if (DenoiseParameters.targetView == undefined) {
      Console.criticalln("!!! You need to choose a view !!!");
    } else {
      colorDenoise(DenoiseParameters.targetView);
      Console.noteln("Successfully denoised using color denoise!");
    }
  } else {
    Console.criticalln("Canceled denoising.");
  }
}
main();
