// ---------- Emission Manager Script ----------
// This script manages the processing of emission images for PixInsight
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check out my astrobin https://www.astrobin.com/users/koperson/
// --------------------------------------

#feature-id kScripts Bundle > kEmissionManager
#feature-info Emission Manager script
#define TITLE "kEmissionManager"
#define VERSION "0.1"

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>

var EMParameters = {
    targetViewBB: undefined,
    targetViewNB: undefined,
    f_r: 0,
    f_g: 0,
    f_b: 0,
};

Console.show();
Console.noteln("Successfully loaded kEmissionManager v", VERSION, "!<br>");

function emDialog() {
    this.__base__ = Dialog;
    this.__base__();

    this.windowTitle = "kScripts - kEmissionManager";
    this.scaledMinWidth = 400;

    this.titleBox = new Label(this);
    this.titleBox.text = "kEmissionManager " + VERSION;
    this.titleBox.textAlignment = TextAlign_Center;
    this.titleBox.styleSheet = "font-weight: bold; font-size: 14pt; background-color: #d7e7fa; border: 1px solid #ccc;";
    this.titleBox.setFixedHeight(30);

    this.instructionsBox = new Label(this);
    this.instructionsBox.text = "Select your images from dropdowns.\nBroadband image should be RGB, but narrowband should by in grayscale.\nChange R channel to remove Ha signal from image (higher=less signal)\nG and B channel for removing Oiii signal.";
    this.instructionsBox.textAlignment = TextAlign_Center;
    this.instructionsBox.styleSheet = "font-size: 8pt; padding: 10px; background-color: #f0f0f0; border: 1px solid #ccc;";
    this.instructionsBox.setFixedHeight(80);

    this.viewListLabelBB = new Label(this);
    this.viewListLabelBB.text = "Broadband Image:";

    this.viewListBB = new ViewList(this);
    this.viewListBB.getMainViews();
    this.viewListBB.onViewSelected = function(view) {
        EMParameters.targetViewBB = view;
    };

    this.viewListLabelNB = new Label(this);
    this.viewListLabelNB.text = "Narrowband Image:";

    this.viewListNB = new ViewList(this);
    this.viewListNB.getMainViews();
    this.viewListNB.onViewSelected = function(view) {
        EMParameters.targetViewNB = view;
    };

    this.f_r_control = new NumericControl(this);
    this.f_r_control.label.text = "R channel:";
    this.f_r_control.setRange(0, 1);
    this.f_r_control.setValue(0.1);
    this.f_r_control.setPrecision(2);
    this.f_r_control.slider.setRange(1, 500);
    this.f_r_control.setValue(EMParameters.f_r);
    this.f_r_control.onValueUpdated = function(value) {
        EMParameters.f_r = value;
    };

    this.f_g_control = new NumericControl(this);
    this.f_g_control.label.text = "G channel:";
    this.f_g_control.setRange(0, 1);
    this.f_g_control.setPrecision(2);
    this.f_g_control.slider.setRange(1, 500);
    this.f_g_control.setValue(EMParameters.f_g);
    this.f_g_control.onValueUpdated = function(value) {
        EMParameters.f_g = value;
    };

    this.f_b_control = new NumericControl(this);
    this.f_b_control.label.text = "B channel:";
    this.f_b_control.setRange(0, 1);
    this.f_b_control.setPrecision(2);
    this.f_b_control.slider.setRange(1, 500);
    this.f_b_control.setValue(EMParameters.f_b);
    this.f_b_control.onValueUpdated = function(value) {
        EMParameters.f_b = value;
    };

    this.executeButton = new PushButton(this);
    this.executeButton.text = "Execute";
    this.executeButton.onClick = () => {
        this.ok();
    }

    this.sizer = new VerticalSizer();
    this.sizer.margin = 20;
    this.sizer.addStretch();
    this.sizer.add(this.titleBox);
    this.sizer.addSpacing(5);
    this.sizer.add(this.instructionsBox);
    this.sizer.addSpacing(10);
    this.sizer.add(this.viewListLabelBB);
    this.sizer.addSpacing(3);
    this.sizer.add(this.viewListBB);
    this.sizer.addSpacing(10);
    this.sizer.add(this.viewListLabelNB);
    this.sizer.addSpacing(3);
    this.sizer.add(this.viewListNB);
    this.sizer.addSpacing(10);
    this.sizer.add(this.f_r_control);
    this.sizer.addSpacing(3);
    this.sizer.add(this.f_g_control);
    this.sizer.addSpacing(3);
    this.sizer.add(this.f_b_control);
    this.sizer.addSpacing(15);
    this.sizer.add(this.executeButton);
}

emDialog.prototype = new Dialog;

function showDialog() {
    let dialog = new emDialog();
    return dialog.execute();
}

function applyPixelMath() {
    let P = new PixelMath;

    P.expression = EMParameters.targetViewBB.fullId + " - " + EMParameters.f_r + " * (" + EMParameters.targetViewNB.fullId + " - med(" + EMParameters.targetViewNB.fullId + "))";
    P.expression1 = EMParameters.targetViewBB.fullId + " - " + EMParameters.f_g + " * (" + EMParameters.targetViewNB.fullId + " - med(" + EMParameters.targetViewNB.fullId + "))";
    P.expression2 = EMParameters.targetViewBB.fullId + " - " + EMParameters.f_b + " * (" + EMParameters.targetViewNB.fullId + " - med(" + EMParameters.targetViewNB.fullId + "))";

    P.useSingleExpression = false;
    P.createNewImage = true;
    P.newImageId = "Emissionless";
    P.newImageWidth = 0;
    P.newImageHeight = 0;
    P.newImageAlpha = false;
    P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
    P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;

    P.executeOn(EMParameters.targetViewBB);
}

function main() {
    let dialog = new emDialog();
    let retVal = dialog.execute();
    Console.show();

    if (!EMParameters.targetViewBB || !EMParameters.targetViewNB) {
        Console.criticalln("!!! Error: Both Broadband and Narrowband images must be selected. !!!");
        return;
    }

    if (EMParameters.targetViewBB.image.colorSpace !== 1) {
        Console.criticalln("!!! Error: Broadband image should be in RGB color space. !!!");
        return;
    }

    if (EMParameters.targetViewNB.image.colorSpace !== 0) {
        Console.criticalln("!!! Error: Narrowband image should be in grayscale. !!!");
        return;
    }

    applyPixelMath();
}

main();
