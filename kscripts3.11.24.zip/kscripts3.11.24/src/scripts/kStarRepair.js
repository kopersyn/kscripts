// ---------- kStarRepair Script ----------
// star repair and combine with starless script for PixInsight
// part of • kScript Bundle •
// made with love by Igor Koprowicz (koperson)
// check my other scripts at https://www.kscripts.pl/
// --------------------------------------

#feature-id kScripts Bundle > kStarRepair
#feature-info Star repair and combine script
#define TITLE "kStarRepair"
#define VERSION "0.3"

#include <pjsr/Sizer.jsh>
#include <pjsr/NumericControl.jsh>

var scriptVersion = "0.3";

var SRParameters = {
  targetView: undefined,
  targetView2: undefined,
  satAmount: 1,
  saturationLevel: [
    [0.00000, 0.40000],
    [0.50000, 0.70000],
    [1.00000, 0.40000]
  ],

  updateSaturationLevel: function() {
    var satAmount = SRParameters.satAmount;
    SRParameters.saturationLevel = [
      [0.00000, satAmount * 0.40000],
      [0.50000, satAmount * 0.70000],
      [1.00000, satAmount * 0.40000]
    ];
  }
};

Console.noteln("Successfully loaded kStarRepair v", scriptVersion, "!<br>");

function krDialog() {
  this.__base__ = Dialog;
  this.__base__();

  this.windowTitle = "kScripts - kStarRepair";

  // scaling
  this.scaledMinWidth = 400;

  // textbox
  this.title = new TextBox(this);
  this.title.text = "<b>kStarRepair</b>" + " v"+ scriptVersion + "<br>" +
                    "Script that which repair <b>star color</b> and <b>mix starless with stars</b>!<br><br>";
  this.title.readOnly = true;
  this.title.minHeight = 80;
  this.title.maxHeight = 100;
  this.title.windowTitle = "kStarRepair";

  // labels for viewlists
  this.viewListLabel = new Label(this);
  this.viewListLabel.text = "Starless image";

  this.viewList2Label = new Label(this);
  this.viewList2Label.text = "Stars image";

  // viewlist
  this.viewList = new ViewList(this);
  this.viewList.getMainViews();
  this.viewList.onViewSelected = function(view) {
    SRParameters.targetView = view;
  }

  // second viewlist
  this.viewList2 = new ViewList(this);
  this.viewList2.getMainViews();
  this.viewList2.onViewSelected = function(view2) {
    SRParameters.targetView2 = view2;
  }

  // color boost control
  this.boostCtrl = new NumericControl(this);
  this.boostCtrl.label.text = "Color boost";
  this.boostCtrl.setRange(0, 5);
  this.boostCtrl.setPrecision(1);
  this.boostCtrl.setValue(SRParameters.satAmount);
  this.boostCtrl.toolTip = "<p>Adjust the color saturation amount.</p>";
  this.boostCtrl.onValueUpdated = function ( value ) {
    SRParameters.satAmount = value;
    SRParameters.updateSaturationLevel();
  }

    // execute
  this.executeButton = new PushButton(this);
  this.executeButton.text = "Execute";
  this.executeButton.onClick = () => {
    this.ok();
  }

  // sizer
  this.sizer = new VerticalSizer();
  this.sizer.margin = 20;
  this.sizer.addStretch();
  this.sizer.add(this.title)
  this.sizer.addSpacing(7);
  this.sizer.add(this.viewListLabel);
  this.sizer.addSpacing(5);
  this.sizer.add(this.viewList);
  this.sizer.addSpacing(10);
  this.sizer.add(this.viewList2Label);
  this.sizer.addSpacing(5);
  this.sizer.add(this.viewList2);
  this.sizer.addSpacing(10);
  this.sizer.add(this.boostCtrl);
  this.sizer.addSpacing(15);
  this.sizer.add(this.executeButton);

}
krDialog.prototype = new Dialog;

function applyColorSaturation(view2, satAmount) {
   var PCS = new ColorSaturation;
   PCS.HS = SRParameters.saturationLevel;
   PCS.HSt = ColorSaturation.prototype.AkimaSubsplines;
   PCS.hueShift = 0.000;
   PCS.executeOn(view2);
}

function applyStarRepair(view2) {
  var PSCNR = new SCNR;
  PSCNR.amount = 1.00;
  PSCNR.protectionMethod = SCNR.prototype.AverageNeutral;
  PSCNR.colorToRemove = SCNR.prototype.Green;
  PSCNR.preserveLightness = true;
  PSCNR.executeOn(view2);

  var PIn1 = new Invert;
  PIn1.executeOn(view2);

  var PSCNR2 = new SCNR;
  PSCNR2.amount = 1.00;
  PSCNR2.protectionMethod = SCNR.prototype.AverageNeutral;
  PSCNR2.colorToRemove = SCNR.prototype.Green;
  PSCNR2.preserveLightness = true;
  PSCNR2.executeOn(view2);

  var PIn2 = new Invert;
  PIn2.executeOn(view2);
}

function combineViews(view, view2) {
  var PPM = new PixelMath;
  PPM.expression = "combine(" + view.id + "," + view2.id + ",op_screen())";
  PPM.expression1 = "";
  PPM.expression2 = "";
  PPM.expression3 = "";
  PPM.useSingleExpression = true;
  PPM.symbols = "";
  PPM.generateOutput = true;
  PPM.singleThreaded = false;
  PPM.use64BitWorkingImage = false;
  PPM.rescale = false;
  PPM.rescaleLower = 0.000000;
  PPM.rescaleUpper = 1.000000;
  PPM.truncate = true;
  PPM.truncateLower = 0.000000;
  PPM.truncateUpper = 1.000000;
  PPM.createNewImage = true;
  PPM.newImageId = "Combined";
  PPM.newImageWidth = 0;
  PPM.newImageHeight = 0;
  PPM.newImageAlpha = false;
  PPM.newImageColorSpace = PixelMath.prototype.SameAsTarget;
  PPM.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
  PPM.executeOn(view);
}

function showDialog() {
  let dialog = new krDialog;
  return dialog.execute();
}


function main() {
    let retVal = showDialog();
    Console.show();

    if(retVal == 1){
      if (SRParameters.targetView == undefined && SRParameters.targetView2 == undefined) {
        Console.criticalln("!!! You haven't chosen any view !!!")
      } else if (SRParameters.targetView == undefined || SRParameters.targetView2 == undefined) {
        Console.criticalln("!!! You need to choose second view !!!")
      } else {
          Console.hide();
          applyColorSaturation(SRParameters.targetView2);
          applyStarRepair(SRParameters.targetView2);
          combineViews(SRParameters.targetView, SRParameters.targetView2);
          Console.noteln("Successfully repaired stars!")
        }
    } else {
      Console.criticalln("Canceled repairing.")
    }
  }
main();
